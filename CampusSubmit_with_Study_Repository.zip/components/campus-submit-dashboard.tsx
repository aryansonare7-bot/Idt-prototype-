'use client'

import { useEffect, useMemo, useState } from 'react'
import {
  ArrowUpRight,
  Award,
  BarChart3,
  BookOpen,
  CalendarDays,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  Download,
  Eye,
  EyeOff,
  FileCheck2,
  FileText,
  History,
  LayoutDashboard,
  Lightbulb,
  Menu,
  MessageCircle,
  MoreHorizontal,
  Paperclip,
  Plus,
  Search,
  Send,
  Settings,
  ShieldCheck,
  Sparkles,
  Target,
  Users,
  X,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'

let publishedAssignments: { title: string; course: string; due: string; documentName?: string; status: string; tone: 'danger' | 'warning' | 'ok'; progress: number; icon: string }[] = []

const assignments = [
  { title: 'C Programming Fundamentals', course: 'FOP · Professor Riya Kumbhare', due: 'Today, 11:59 PM', status: 'Due very soon', tone: 'danger', progress: 72, icon: 'FOP' },
  { title: 'Digital Circuits Lab', course: 'DLD · Professor Jayu Kalambe', due: 'Tomorrow, 5:00 PM', status: 'Due soon', tone: 'warning', progress: 48, icon: 'DLD' },
  { title: 'Basic Electronics Worksheet', course: 'BE · Professor Poorvi Joshi', due: 'May 28, 2025', status: 'On track', tone: 'success', progress: 25, icon: 'BE' },
  { title: 'Probability & Statistics / IDT Set', course: 'Probability and Stats · Professor Vishakha Mahajan', due: 'May 31, 2025', status: 'On track', tone: 'success', progress: 10, icon: 'P&S' },
  { title: 'Innovation Design Challenge', course: 'IDT · Professor Parag Jawarkar', due: 'June 2, 2025', status: 'On track', tone: 'success', progress: 8, icon: 'IDT' },
]

const navItems = [
  { label: 'Overview', icon: LayoutDashboard },
  { label: 'Assignments', icon: FileText },
  { label: 'Study materials', icon: BookOpen },
  { label: 'Study planner', icon: CalendarDays },

]

function StatusBadge({ status, tone }: { status: string; tone: string }) {
  const styles = tone === 'danger' ? 'bg-rose-50 text-rose-700 border-rose-100' : tone === 'warning' ? 'bg-amber-50 text-amber-700 border-amber-100' : 'bg-emerald-50 text-emerald-700 border-emerald-100'
  return <Badge variant="outline" className={styles}>{status}</Badge>
}

export default function CampusSubmitDashboard() {
  const [activeNav, setActiveNav] = useState('Overview')
  const [role, setRole] = useState<'student' | 'faculty'>('student')
  const [mobileNav, setMobileNav] = useState(false)
  const [showUpload, setShowUpload] = useState(false)
  const [fileName, setFileName] = useState('')
  const [selectedAssignment, setSelectedAssignment] = useState('')
  const [doubt, setDoubt] = useState('')
  const [doubtSent, setDoubtSent] = useState(false)
  const [completedFeedback, setCompletedFeedback] = useState<string[]>([])
  const [facultyUnlocked, setFacultyUnlocked] = useState(false)
  const [teacherLoginOpen, setTeacherLoginOpen] = useState(false)
  const [teacherPassword, setTeacherPassword] = useState('')
  const [teacherError, setTeacherError] = useState('')
  const [adminOpen, setAdminOpen] = useState(false)
  const [adminPassword, setAdminPassword] = useState('')
  const [adminError, setAdminError] = useState('')
  const [showTeacherPassword, setShowTeacherPassword] = useState(false)
  const [showAdminPassword, setShowAdminPassword] = useState(false)
  const [notificationsOpen, setNotificationsOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')

  const searchResults = assignments.filter((assignment) => `${assignment.title} ${assignment.course} ${assignment.professor}`.toLowerCase().includes(searchQuery.toLowerCase().trim()))
  const [submittedAssignments, setSubmittedAssignments] = useState<string[]>([])
  const [submissionHistory, setSubmissionHistory] = useState<{ title: string; fileName: string; submittedAt: string }[]>([])

  function toggleAssignmentSubmission(title: string) {
    setSubmittedAssignments((current) => current.filter((item) => item !== title))
    setSubmissionHistory((current) => current.filter((item) => item.title !== title))
  }

  function submitAssignment(title: string, fileName: string) {
    setSubmittedAssignments((current) => current.includes(title) ? current : [...current, title])
    setSubmissionHistory((current) => [{ title, fileName, submittedAt: new Date().toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) }, ...current.filter((item) => item.title !== title)])
  }

  const incompleteAssignments = assignments.filter((assignment) => assignment.progress < 100)
  const studentAssignments = [...publishedAssignments, ...incompleteAssignments]
  const completedCount = completedFeedback.length
  const greeting = useMemo(() => role === 'student' ? 'Good morning, Demo Student' : 'Good morning, Demo Teacher', [role])
  const currentDate = useMemo(() => new Intl.DateTimeFormat('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric', timeZone: 'UTC' }).format(new Date()), [])

  function openFacultyAccess() {
    if (facultyUnlocked) setRole('faculty')
    else {
      setRole('faculty')
      setTeacherLoginOpen(true)
    }
  }

  function openDemoTeacher() {
    setFacultyUnlocked(true)
    setTeacherLoginOpen(false)
    setRole('faculty')
  }

  function unlockFaculty() {
    if (teacherPassword !== 'teacher@123') {
      setTeacherError('Incorrect teacher password.')
      return
    }
    setFacultyUnlocked(true)
    setRole('faculty')
    setTeacherLoginOpen(false)
    setTeacherPassword('')
    setTeacherError('')
  }

  function unlockAdmin() {
    if (adminPassword !== 'admin@123') {
      setAdminError('Incorrect admin password.')
      return
    }
    setAdminOpen(true)
    setAdminPassword('')
    setAdminError('')
  }

  function submitDoubt() {
    if (!doubt.trim()) return
    setDoubtSent(true)
    setDoubt('')
  }

  return (
    <div className="min-h-screen bg-[#f7f8fc] text-slate-900">
      <aside className={`fixed inset-y-0 left-0 z-30 flex w-[248px] flex-col border-r border-slate-200 bg-white px-4 py-5 transition-transform lg:translate-x-0 ${mobileNav ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center gap-3 px-3">
          <div className="flex size-9 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-sm"><ShieldCheck className="size-5" /></div>
          <div><p className="text-[15px] font-bold tracking-tight">CampusSubmit</p><p className="text-[10px] font-medium uppercase tracking-[0.18em] text-slate-400">Learn · Submit · Grow</p></div>
        </div>
        <div className="mt-9 flex flex-1 flex-col gap-1">
          <p className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-400">Workspace</p>
          {navItems.filter(({ label }) => role === 'student' || !['Study planner', 'Feedback', 'Achievements'].includes(label)).map(({ label, icon: Icon }) => <button key={label} onClick={() => { setActiveNav(label); setMobileNav(false) }} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${activeNav === label ? 'bg-indigo-50 text-indigo-700' : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'}`}><Icon className="size-[17px]" />{label}{label === 'Feedback' && <span className="ml-auto rounded-full bg-indigo-600 px-1.5 py-0.5 text-[10px] font-bold text-white">3</span>}</button>)}
          <p className="mt-8 px-3 pb-2 text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-400">Community</p>
          <button onClick={() => setActiveNav('Doubt box')} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium ${activeNav === 'Doubt box' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-500 hover:bg-slate-50'}`}><CircleHelp className="size-[17px]" />Anonymous doubt box</button>
        </div>
        <div className="rounded-2xl bg-slate-50 p-3"><div className="flex items-center gap-2"><div className="flex size-8 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-500 text-xs font-bold text-white">AH</div><div className="min-w-0 flex-1"><p className="truncate text-xs font-semibold">{role === 'student' ? 'Demo Student' : 'Demo Teacher'}</p><p className="truncate text-[11px] text-slate-400">{role === 'student' ? 'ECS · Year 1' : 'ECS Department'}</p></div><MoreHorizontal className="size-4 text-slate-400" /></div></div>
      </aside>
      {mobileNav && <button aria-label="Close navigation" onClick={() => setMobileNav(false)} className="fixed inset-0 z-20 bg-slate-900/20 lg:hidden"><X className="sr-only" /></button>}

      <main className="min-h-screen lg:pl-[248px]">
        <header className="flex h-[72px] items-center justify-between border-b border-slate-200 bg-white px-5 sm:px-8">
          <div className="flex items-center gap-3"><Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setMobileNav(true)}><Menu /></Button>{role === 'student' && <div className="relative hidden w-64 sm:block"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" /><input aria-label="Search assignments" value={searchQuery} onChange={(event) => setSearchQuery(event.target.value)} placeholder="Search anything" className="h-9 w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 text-sm outline-none placeholder:text-slate-400 focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100" /></div>}<span className="text-sm font-medium text-slate-500 sm:hidden">{activeNav}</span></div>
          <div className="flex items-center gap-2 sm:gap-4"><div className="h-6 w-px bg-slate-200" /><button onClick={() => role === 'student' ? openFacultyAccess() : setRole('student')} className="flex items-center gap-2 rounded-lg border border-slate-200 px-2 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-50"><span className="hidden sm:inline">{role === 'student' ? 'Student view' : 'Faculty view'}</span><ChevronDown className="size-3.5" /></button></div>
  </header>
  {role === 'faculty' && !facultyUnlocked && <TeacherLogin password={teacherPassword} setPassword={setTeacherPassword} error={teacherError} showPassword={showTeacherPassword} setShowPassword={setShowTeacherPassword} onUnlock={unlockFaculty} />}
  {searchQuery.trim() && <div className="absolute left-5 top-[82px] z-20 w-80 rounded-xl border border-slate-200 bg-white p-3 shadow-xl sm:left-8"><div className="mb-2 flex items-center justify-between"><p className="text-sm font-semibold">Search results</p><span className="text-xs text-slate-400">{searchResults.length} found</span></div>{searchResults.length > 0 ? <div className="flex flex-col gap-1">{searchResults.map((assignment) => <button key={assignment.title} className="rounded-lg p-2 text-left hover:bg-indigo-50" onClick={() => { setActiveNav('Assignments'); setSearchQuery('') }}><p className="text-sm font-medium">{assignment.title}</p><p className="text-xs text-slate-500">{assignment.course} · {assignment.due}</p></button>)}</div> : <p className="p-2 text-sm text-slate-500">No assignments match your search.</p>}</div>}
  {false && (
    <div className="absolute right-5 top-[82px] z-20 w-[min(360px,calc(100vw-2rem))] rounded-xl border border-slate-200 bg-white p-4 shadow-xl sm:right-8" role="status">
      <div className="flex items-center justify-between">
        <div><h2 className="font-semibold text-slate-950">Incomplete assignments</h2><p className="mt-1 text-xs text-slate-500">{incompleteAssignments.length} still need your attention.</p></div>
        
      </div>
      <div className="mt-3 flex flex-col gap-2">
        {incompleteAssignments.map((assignment) => (
          <button key={assignment.title} onClick={() => { setActiveNav('Assignments'); setNotificationsOpen(false) }} className="rounded-lg bg-slate-50 p-3 text-left hover:bg-indigo-50">
            <p className="text-sm font-medium text-slate-900">{assignment.title}</p><p className="mt-1 text-xs text-slate-500">{assignment.due} · {assignment.status}</p>
          </button>
        ))}
      </div>
    </div>
  )}
  <div className="mx-auto max-w-[1320px] px-5 py-7 sm:px-8 lg:px-10">
          <div className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><p className="mb-1 text-sm font-medium text-indigo-600">{currentDate}</p><h1 className="text-2xl font-bold tracking-tight sm:text-[28px]">{greeting}</h1><p className="mt-1 text-sm text-slate-500">{role === 'student' ? 'Here is your academic pulse for today.' : 'Here is what needs your attention today.'}</p></div></div>

          {activeNav !== 'Overview' ? <section className="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm"><h2 className="text-xl font-bold">{activeNav}</h2>{activeNav === 'Study materials' && role === 'student' ? <MaterialRepository /> : activeNav === 'Study planner' && role === 'student' ? <div className="mt-5 grid gap-3 sm:grid-cols-3"><div className="rounded-xl bg-indigo-50 p-4"><p className="text-xs font-semibold uppercase tracking-wide text-indigo-600">Today</p><p className="mt-2 font-semibold text-slate-900">90-minute focus block</p><p className="mt-1 text-sm text-slate-600">Finish your Probability & Statistics / IDT set.</p></div><div className="rounded-xl bg-amber-50 p-4"><p className="text-xs font-semibold uppercase tracking-wide text-amber-700">Next up</p><p className="mt-2 font-semibold text-slate-900">DLD problem set</p><p className="mt-1 text-sm text-slate-600">Due in 3 days. Review logic gates first.</p></div><div className="rounded-xl bg-emerald-50 p-4"><p className="text-xs font-semibold uppercase tracking-wide text-emerald-700">Suggested</p><p className="mt-2 font-semibold text-slate-900">25-minute review</p><p className="mt-1 text-sm text-slate-600">Revise C pointers before FOP.</p></div></div> : activeNav === 'Doubt box' && role === 'student' ? <div className="mt-5 rounded-xl border border-indigo-100 bg-indigo-50/60 p-4"><p className="text-sm text-slate-600">Ask an anonymous question and your instructor can respond.</p><textarea value={doubt} onChange={(event) => setDoubt(event.target.value)} placeholder="Type your doubt here..." rows={5} className="mt-4 w-full rounded-lg border border-slate-200 bg-white p-3 text-sm outline-none focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100" />{doubtSent && <p className="mt-2 text-sm font-medium text-emerald-600">Your doubt was sent anonymously.</p>}<div className="mt-3 flex justify-end"><Button onClick={submitDoubt} disabled={!doubt.trim()} className="bg-sky-500 text-white hover:bg-sky-600">Send doubt</Button></div></div> : activeNav === 'Assignments' && role === 'student' ? <><div className="mt-5 flex flex-col gap-3"><div className="flex items-center justify-between"><p className="text-sm text-slate-500">Turn in pending work before each deadline.</p><Badge variant="secondary">{studentAssignments.length - submittedAssignments.length} remaining</Badge></div>{studentAssignments.map((assignment) => { const isSubmitted = submittedAssignments.includes(assignment.title); return <div key={assignment.title} className="flex flex-col gap-3 rounded-xl border border-slate-200 p-4 sm:flex-row sm:items-center sm:justify-between"><div><p className="font-semibold">{assignment.title}</p><p className="mt-1 text-sm text-slate-500">{assignment.course} · Due {assignment.due}</p></div><Button variant={isSubmitted ? 'outline' : 'default'} className={isSubmitted ? 'border-slate-300 text-slate-700' : 'bg-sky-500 text-white hover:bg-sky-600'} onClick={() => { if (isSubmitted) { toggleAssignmentSubmission(assignment.title) } else { setSelectedAssignment(assignment.title); setFileName(''); setShowUpload(true) } }}>{isSubmitted ? 'Undo submission' : 'Turn in assignment'}</Button></div> })}</div>{submissionHistory.length > 0 && <div className="mt-6 border-t border-slate-200 pt-5"><div className="flex items-center justify-between"><div><h3 className="font-semibold">Submission history</h3><p className="mt-1 text-xs text-slate-500">Files you have turned in recently.</p></div><History className="size-5 text-indigo-500" /></div><div className="mt-3 flex flex-col gap-2">{submissionHistory.map((submission) => <div key={`${submission.title}-${submission.submittedAt}`} className="flex flex-col gap-2 rounded-lg bg-slate-50 p-3 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-sm font-medium">{submission.title}</p><p className="mt-1 text-xs text-slate-500">{submission.fileName} · {submission.submittedAt}</p></div><span className="w-fit rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-semibold text-emerald-700">Submitted</span></div>)}</div></div>}</> : activeNav === 'Doubt box' && role === 'faculty' ? <TeacherDoubtPanel /> : role === 'faculty' ? <TeacherPublishForm /> : <p className="mt-2 text-sm text-slate-500">This section is ready for student activity.</p>}<Button className="mt-5 bg-sky-100 text-black hover:bg-sky-200" onClick={() => setActiveNav('Overview')}>Back to overview</Button></section> : role === 'student' ? <StudentView completedCount={completedCount} completedFeedback={completedFeedback} setCompletedFeedback={setCompletedFeedback} setShowUpload={setShowUpload} setActiveNav={setActiveNav} activeNav={activeNav} role={role} setDoubt={setDoubt} doubt={doubt} submitDoubt={submitDoubt} doubtSent={doubtSent} /> : facultyUnlocked ? <FacultyView /> : <TeacherLogin onUnlock={unlockFaculty} password={teacherPassword} setPassword={setTeacherPassword} error={teacherError} showPassword={showTeacherPassword} setShowPassword={setShowTeacherPassword} onCreateTeacher={() => { setTeacherLoginOpen(false); setAdminOpen(true) }} />}
          
        </div>
      </main>

      {showUpload && <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/30 p-4"><div role="dialog" aria-modal="true" className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl"><div className="flex items-start justify-between"><div><h2 className="text-lg font-bold">Submit assignment</h2><p className="mt-1 text-sm text-slate-500">{selectedAssignment || 'Choose an assignment to submit'}</p></div><button aria-label="Close dialog" onClick={() => setShowUpload(false)} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100"><X className="size-5" /></button></div><div className="mt-6 rounded-xl border-2 border-dashed border-indigo-200 bg-indigo-50/40 p-8 text-center"><input id="assignment-file" type="file" accept=".pdf,.doc,.docx,.txt" className="sr-only" onChange={(e) => setFileName(e.target.files?.[0]?.name ?? '')} /><label htmlFor="assignment-file" className="flex cursor-pointer flex-col items-center gap-2"><div className="flex size-11 items-center justify-center rounded-full bg-white text-indigo-600 shadow-sm"><Paperclip className="size-5" /></div><span className="text-sm font-semibold text-slate-700">{fileName || 'Choose a file to upload'}</span><span className="text-xs text-slate-500">PDF, DOC, DOCX or TXT · Max 10 MB</span></label></div>{fileName && <div className="mt-4 flex items-center justify-between rounded-lg bg-emerald-50 px-3 py-2.5 text-sm text-emerald-700"><span className="flex items-center gap-2"><FileCheck2 className="size-4" />File format verified</span><Check className="size-4" /></div>}<div className="mt-6 flex justify-end gap-2"><Button variant="outline" onClick={() => setShowUpload(false)} className="border-slate-300 bg-slate-100 text-slate-700 hover:bg-slate-200">Cancel</Button><Button disabled={!fileName} onClick={() => { if (selectedAssignment && fileName) submitAssignment(selectedAssignment, fileName); setShowUpload(false); setFileName('') }} className="bg-indigo-600 hover:bg-indigo-700">Submit for review</Button></div></div></div>}
    </div>
  )
}

function StudentView({ completedCount, completedFeedback, setCompletedFeedback, setShowUpload, setActiveNav, activeNav, role, setDoubt, doubt, submitDoubt, doubtSent }: { completedCount: number; completedFeedback: string[]; setCompletedFeedback: (items: string[]) => void; setShowUpload: (value: boolean) => void; setActiveNav: (value: string) => void; activeNav: string; role: 'student' | 'faculty'; setDoubt: (value: string) => void; doubt: string; submitDoubt: () => void; doubtSent: boolean }) {
  return <>
    {activeNav === 'Assignments' && role === 'student' && <section className="mb-6 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="mb-4 flex items-center justify-between"><div><h2 className="font-bold">Pending assignments</h2><p className="mt-1 text-xs text-slate-500">Turn work in before the deadline, or undo a submission while the deadline is still open.</p></div><Badge variant="secondary">{studentAssignments.length - submittedAssignments.length} remaining</Badge></div><div className="flex flex-col gap-3">{studentAssignments.map((assignment) => { const isSubmitted = submittedAssignments.includes(assignment.title); return <div key={assignment.title} className="flex flex-col gap-3 rounded-xl border border-slate-200 p-4 sm:flex-row sm:items-center sm:justify-between"><div><div className="flex flex-wrap items-center gap-2"><p className="font-semibold">{assignment.title}</p><StatusBadge status={assignment.status} tone={assignment.tone} /></div><p className="mt-1 text-sm text-slate-500">{assignment.course} · Due {assignment.due}</p></div><Button variant={isSubmitted ? 'outline' : 'default'} className={isSubmitted ? 'border-slate-300 text-slate-700' : 'bg-sky-500 text-white hover:bg-sky-600'} onClick={() => { if (isSubmitted) { toggleAssignmentSubmission(assignment.title) } else { setSelectedAssignment(assignment.title); setFileName(''); setShowUpload(true) } }}>{isSubmitted ? 'Undo submission' : 'Turn in assignment'}</Button></div> })}</div></section>}

  <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><StatCard icon={FileText} label="Total assignments" value="12" meta="2 due this week" color="indigo" /><StatCard icon={Clock3} label="Pending submissions" value="4" meta="1 due today" color="amber" /><StatCard icon={BarChart3} label="Average mark" value="86%" meta="+4.2% this term" color="emerald" /><StatCard icon={MessageCircle} label="New feedback" value="3" meta="2 actions to complete" color="violet" /></div>
    <div className="mt-6 grid gap-6 xl:grid-cols-[1.35fr_0.65fr]">
      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="mb-5 flex items-center justify-between"><div><h2 className="font-bold">Assignment risk radar</h2><p className="mt-1 text-xs text-slate-500">Keep an eye on what is coming up next.</p></div><Button variant="ghost" size="sm" className="text-indigo-600" onClick={() => setActiveNav('Assignments')}>View all <ArrowUpRight data-icon="inline-end" /></Button></div><div className="flex flex-col gap-3">{assignments.map((assignment) => <div key={assignment.title} className="group flex items-center gap-3 rounded-xl border border-slate-100 p-3 transition hover:border-indigo-100 hover:bg-indigo-50/30"><div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-[11px] font-bold text-slate-500">{assignment.icon}</div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><p className="truncate text-sm font-semibold">{assignment.title}</p><StatusBadge status={assignment.status} tone={assignment.tone} /></div><p className="mt-1 text-xs text-slate-500">{assignment.course} <span className="mx-1 text-slate-300">·</span> Due {assignment.due}</p><div className="mt-2 h-1.5 w-full max-w-[240px] overflow-hidden rounded-full bg-slate-100"><div className={`h-full rounded-full ${assignment.tone === 'danger' ? 'bg-rose-400' : assignment.tone === 'warning' ? 'bg-amber-400' : 'bg-emerald-400'}`} style={{ width: `${assignment.progress}%` }} /></div></div><Button size="sm" variant="ghost" onClick={() => setShowUpload(true)} className="hidden text-indigo-600 group-hover:flex">Open</Button></div>)}</div></section>
      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="mb-4 flex items-center justify-between"><div><h2 className="font-bold">Your progress</h2><p className="mt-1 text-xs text-slate-500">Term 2 · 2024–25</p></div><Button variant="ghost" size="icon"><MoreHorizontal /></Button></div><div className="flex items-center gap-5"><div className="relative flex size-28 items-center justify-center rounded-full" style={{ background: 'conic-gradient(#6366f1 0 86%, #e9eafe 86% 100%)' }}><div className="flex size-[88px] items-center justify-center rounded-full bg-white"><span className="text-2xl font-bold">86<span className="text-sm">%</span></span></div></div><div className="flex flex-col gap-2 text-xs"><div className="flex items-center gap-2"><span className="size-2 rounded-full bg-indigo-500" />Average mark <strong className="ml-auto">86%</strong></div><div className="flex items-center gap-2"><span className="size-2 rounded-full bg-emerald-400" />On-time rate <strong className="ml-auto">92%</strong></div><div className="flex items-center gap-2"><span className="size-2 rounded-full bg-amber-400" />Feedback done <strong className="ml-auto">{completedCount + 4}/6</strong></div></div></div><div className="mt-6 rounded-xl bg-indigo-50 p-3"><p className="flex items-center gap-2 text-xs font-semibold text-indigo-800"><Sparkles className="size-3.5" /> You are 8% above your cohort average</p></div></section>
    </div>

    <div className="mt-6 grid gap-6 lg:grid-cols-[0.8fr_1.2fr]"><section className="rounded-2xl border border-indigo-100 bg-indigo-600 p-5 text-white shadow-sm"><div className="flex items-start justify-between"><div><p className="text-sm font-semibold text-indigo-100">Smart study planner</p><h2 className="mt-1 text-xl font-bold">Make time for what matters.</h2></div><Target className="size-6 text-indigo-200" /></div><p className="mt-3 text-sm leading-relaxed text-indigo-100">You have 3 hours free today. We found a focused 90-minute block for your PSY 204 reflection.</p><Button variant="secondary" className="mt-5 bg-white text-indigo-700 hover:bg-indigo-50" onClick={() => setActiveNav('Study planner')}>Open planner <ArrowUpRight data-icon="inline-end" /></Button></section><section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="flex items-center justify-between"><div><h2 className="font-bold">Anonymous doubt box</h2><p className="mt-1 text-xs text-slate-500">Ask without attaching your name.</p></div><CircleHelp className="size-5 text-indigo-500" /></div>{doubtSent ? <div className="mt-4 flex items-center gap-2 rounded-xl bg-emerald-50 p-3 text-sm text-emerald-700"><Check className="size-4" />Your doubt was sent anonymously. Faculty will respond soon.</div> : <div className="mt-4 flex gap-2"><input value={doubt} onChange={(e) => setDoubt(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.nativeEvent.isComposing && e.keyCode !== 229) submitDoubt() }} placeholder="What would you like help with?" className="h-10 min-w-0 flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm outline-none focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100" /><Button aria-label="Send anonymous doubt" size="icon" onClick={submitDoubt} className="bg-indigo-600 hover:bg-indigo-700"><Send /></Button></div>}</section></div>
  </>
}

type MaterialItem = { id: string; title: string; subject: string; fileName: string; type: string; createdAt: string }

function MaterialRepository() {
  const [materials, setMaterials] = useState<MaterialItem[]>([])
  const [title, setTitle] = useState('')
  const [subject, setSubject] = useState('')
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [message, setMessage] = useState('')

  function openDb(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('CampusSubmitMaterials', 1)
      request.onupgradeneeded = () => {
        const db = request.result
        if (!db.objectStoreNames.contains('materials')) db.createObjectStore('materials', { keyPath: 'id' })
      }
      request.onsuccess = () => resolve(request.result)
      request.onerror = () => reject(request.error)
    })
  }

  async function refreshMaterials() {
    try {
      const db = await openDb()
      const request = db.transaction('materials', 'readonly').objectStore('materials').getAll()
      request.onsuccess = () => setMaterials((request.result as (MaterialItem & { blob: Blob })[]).sort((a, b) => b.createdAt.localeCompare(a.createdAt)))
    } catch { setMessage('Storage is unavailable in this browser.') }
  }

  useEffect(() => { refreshMaterials() }, [])

  async function uploadMaterial() {
    if (!title.trim() || !subject.trim() || !selectedFile) return
    if (selectedFile.size > 15 * 1024 * 1024) { setMessage('Please choose a file smaller than 15 MB.'); return }
    const item = { id: `${Date.now()}-${Math.random().toString(36).slice(2)}`, title: title.trim(), subject: subject.trim(), fileName: selectedFile.name, type: selectedFile.type || 'application/octet-stream', createdAt: new Date().toISOString(), blob: selectedFile }
    try {
      const db = await openDb()
      const tx = db.transaction('materials', 'readwrite')
      tx.objectStore('materials').put(item)
      tx.oncomplete = () => { setTitle(''); setSubject(''); setSelectedFile(null); setMessage('Material saved on this device.'); refreshMaterials() }
      tx.onerror = () => setMessage('Could not save this file. Try a smaller file.')
    } catch { setMessage('Could not access browser storage.') }
  }

  async function downloadMaterial(id: string) {
    const db = await openDb()
    const request = db.transaction('materials', 'readonly').objectStore('materials').get(id)
    request.onsuccess = () => {
      if (!request.result) return
      const url = URL.createObjectURL(request.result.blob)
      const link = document.createElement('a')
      link.href = url; link.download = request.result.fileName; link.click()
      URL.revokeObjectURL(url)
    }
  }

  async function deleteMaterial(id: string) {
    const db = await openDb()
    const tx = db.transaction('materials', 'readwrite')
    tx.objectStore('materials').delete(id)
    tx.oncomplete = () => refreshMaterials()
  }

  return <div className="mt-5 space-y-6">
    <div className="rounded-xl border border-indigo-100 bg-indigo-50/60 p-4"><h3 className="font-semibold text-slate-900">Share study resources</h3><p className="mt-1 text-sm text-slate-600">Upload notes, PDFs, lab manuals and question papers.</p>
      <div className="mt-4 grid gap-3 sm:grid-cols-2"><input value={title} onChange={e => setTitle(e.target.value)} placeholder="Material title" className="h-10 rounded-lg border border-slate-200 bg-white px-3 text-sm"/><input value={subject} onChange={e => setSubject(e.target.value)} placeholder="Subject (e.g. Basic Electronics)" className="h-10 rounded-lg border border-slate-200 bg-white px-3 text-sm"/></div>
      <div className="mt-3 flex flex-col gap-3 sm:flex-row sm:items-center"><input type="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.txt,.jpg,.png" onChange={e => setSelectedFile(e.target.files?.[0] ?? null)} className="min-w-0 flex-1 text-sm"/><Button onClick={uploadMaterial} disabled={!title.trim() || !subject.trim() || !selectedFile} className="bg-indigo-600 hover:bg-indigo-700"><Plus className="mr-1 size-4"/>Upload material</Button></div>
      <p className="mt-2 text-xs text-slate-500">Maximum 15 MB per file. Supported: PDF, Word, PowerPoint, TXT and images.</p>
    </div>
    {message && <p role="status" className="text-sm text-emerald-700">{message}</p>}
    <div><div className="mb-3 flex items-center justify-between"><h3 className="font-semibold">Available materials</h3><Badge variant="secondary">{materials.length} files</Badge></div>
      {materials.length === 0 ? <div className="rounded-xl border border-dashed border-slate-300 p-8 text-center"><BookOpen className="mx-auto size-8 text-slate-300"/><p className="mt-2 text-sm font-medium text-slate-600">No study materials yet</p><p className="mt-1 text-xs text-slate-400">Upload the first notes or question paper.</p></div> : <div className="space-y-2">{materials.map(item => <div key={item.id} className="flex flex-col gap-3 rounded-xl border border-slate-200 p-3 sm:flex-row sm:items-center"><div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600"><FileText className="size-5"/></div><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{item.title}</p><p className="mt-1 text-xs text-slate-500">{item.subject} · {item.fileName}</p><p className="mt-1 text-[11px] text-slate-400">Added {new Date(item.createdAt).toLocaleDateString()}</p></div><div className="flex gap-2"><Button size="sm" onClick={() => downloadMaterial(item.id)} className="bg-sky-500 text-white hover:bg-sky-600"><Download className="mr-1 size-4"/>Download</Button><Button size="sm" variant="outline" onClick={() => deleteMaterial(item.id)}>Delete</Button></div></div>)}</div>}
    </div>
    <p className="rounded-lg bg-amber-50 p-3 text-xs leading-relaxed text-amber-800">Prototype storage: files are saved in this browser on this device. To share uploaded files with all students and faculty, connect a shared online storage service and database before publishing.</p>
  </div>
}

function TeacherLogin({ onUnlock, password, setPassword, error, showPassword, setShowPassword }: { onUnlock: () => void; password: string; setPassword: (value: string) => void; error: string; showPassword: boolean; setShowPassword: (value: boolean) => void }) {
  return <section className="mx-auto max-w-lg rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
    <div className="mb-6 flex items-start gap-3"><div className="flex size-11 items-center justify-center rounded-xl bg-indigo-100 text-indigo-700"><ShieldCheck className="size-5" /></div><div><h2 className="text-lg font-bold">Teacher Profile</h2><p className="mt-1 text-sm text-slate-500">Sign in to publish assignments, review submissions, evaluate work, and answer doubts.</p></div></div>
    <label htmlFor="teacher-password" className="text-sm font-semibold text-slate-700">Teacher password</label><div className="relative mt-2"><input id="teacher-password" type={showPassword ? 'text' : 'password'} value={password} onChange={(event) => setPassword(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.nativeEvent.isComposing && event.keyCode !== 229) onUnlock() }} placeholder="Enter teacher password" className="h-11 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 pr-11 text-sm outline-none focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100" /><button type="button" aria-label={showPassword ? 'Hide password' : 'Show password'} onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700">{showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}</button></div>{error && <p className="mt-2 text-sm text-rose-600" role="alert">{error}</p>}<Button onClick={onUnlock} className="mt-4 w-full bg-sky-100 text-black hover:bg-sky-200">Open demo teacher profile</Button>
  </section>
}

function AdminProfileForm({ password, setPassword, error, showPassword, setShowPassword, onUnlock, onCancel }: { password: string; setPassword: (value: string) => void; error: string; showPassword: boolean; setShowPassword: (value: boolean) => void; onUnlock: () => void; onCancel: () => void }) {
  return <section className="mx-auto max-w-lg rounded-2xl border border-amber-200 bg-amber-50/50 p-6 shadow-sm"><div className="mb-5 flex items-start gap-3"><div className="flex size-11 items-center justify-center rounded-xl bg-amber-100 text-amber-700"><ShieldCheck className="size-5" /></div><div><h2 className="text-lg font-bold">Create new teacher profile</h2><p className="mt-1 text-sm text-slate-500">Enter the admin password to continue.</p></div></div><label htmlFor="admin-password" className="text-sm font-semibold text-slate-700">Admin password</label><div className="relative mt-2"><input id="admin-password" type={showPassword ? 'text' : 'password'} value={password} onChange={(event) => setPassword(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') onUnlock() }} placeholder="Enter admin password" className="h-11 w-full rounded-lg border border-slate-200 bg-white px-3 pr-11 text-sm outline-none focus:border-amber-300 focus:ring-2 focus:ring-amber-100" /><button type="button" aria-label={showPassword ? 'Hide password' : 'Show password'} onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700">{showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}</button></div>{error && <p className="mt-2 text-sm text-rose-600" role="alert">{error}</p>}<div className="mt-5 flex justify-end gap-2"><Button variant="outline" onClick={onCancel}>Cancel</Button><Button onClick={onUnlock} className="bg-amber-600 hover:bg-amber-700">Continue</Button></div></section>
}

function TeacherDoubtPanel() {
  const [selected, setSelected] = useState<string | null>(null)
  const [answer, setAnswer] = useState('')
  const [answered, setAnswered] = useState<string[]>([])
  const doubts = ['FOP: How do I approach the next problem set?', 'FOP: Which problem-solving method should we use?', 'Mathematics: How do I solve the limits question?', 'Mathematics: Could you explain mean versus median?', 'BE: Can you explain the diode circuit from today’s lab?', 'BE: Which components should we use for the practical assignment?', 'DLD: How does the flip-flop timing work?', 'DLD: Will the digital logic lab include Karnaugh maps?']
  function sendAnswer() { if (!selected || !answer.trim()) return; setAnswered((items) => [...items, selected]); setSelected(null); setAnswer('') }
  return <div className="mt-5"><p className="text-sm text-slate-500">View every anonymous student doubt and respond by subject.</p><div className="mt-4 flex flex-col gap-3">{doubts.map((doubt) => <div key={doubt} className="rounded-xl border border-slate-200 p-4"><div className="flex items-start justify-between gap-4"><div><p className="font-medium text-slate-900">{doubt}</p><p className="mt-1 text-xs text-slate-500">Anonymous student</p></div>{answered.includes(doubt) ? <span className="text-sm font-semibold text-emerald-600">Answered</span> : <Button onClick={() => setSelected(doubt)} className="bg-sky-500 text-white hover:bg-sky-600">Respond</Button>}</div>{selected === doubt && <div className="mt-4 border-t border-slate-100 pt-4"><textarea value={answer} onChange={(event) => setAnswer(event.target.value)} placeholder="Write your answer..." rows={3} className="w-full rounded-lg border border-slate-200 p-3 text-sm outline-none focus:border-indigo-300" /><div className="mt-2 flex justify-end gap-2"><Button variant="outline" onClick={() => { setSelected(null); setAnswer('') }} className="border-sky-200 bg-sky-50 text-sky-700 hover:bg-sky-100">Cancel</Button><Button onClick={sendAnswer} disabled={!answer.trim()} className="bg-sky-500 text-white hover:bg-sky-600">Send answer</Button></div></div>}</div>)}</div></div>
}

function TeacherPublishForm() {
  const [title, setTitle] = useState('')
  const [course, setCourse] = useState('')
  const [dueDate, setDueDate] = useState('')
  const [documentName, setDocumentName] = useState('')
  const [published, setPublished] = useState<{ title: string; course: string; dueDate: string; documentName?: string }[]>(() => publishedAssignments.map((item) => ({ title: item.title, course: item.course, dueDate: item.due, documentName: item.documentName })) )
  const [editingDueDate, setEditingDueDate] = useState<string | null>(null)
  const [newDueDate, setNewDueDate] = useState('')

  function publishAssignment() {
    if (!title.trim() || !course.trim() || !dueDate) return
    const assignment = { title: title.trim(), course, due: dueDate, documentName: documentName || undefined, status: 'Due soon', tone: 'warning' as const, progress: 0, icon: course.slice(0, 2).toUpperCase() }
    publishedAssignments = [assignment, ...publishedAssignments.filter((item) => item.title !== assignment.title)]
    setPublished((current) => [{ title: title.trim(), course: course.trim(), dueDate, documentName: documentName || undefined }, ...current])
    setTitle(''); setCourse(''); setDueDate(''); setDocumentName('')
  }

  function extendDueDate(title: string) {
    if (!newDueDate) return
    setPublished((current) => current.map((item) => item.title === title ? { ...item, dueDate: newDueDate } : item))
    publishedAssignments = publishedAssignments.map((item) => item.title === title ? { ...item, due: newDueDate } : item)
    setEditingDueDate(null); setNewDueDate('')
  }

  return <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_0.9fr]">
    <div className="rounded-xl border border-indigo-100 bg-indigo-50/60 p-4"><h3 className="font-semibold">Publish a new assignment</h3><p className="mt-1 text-xs text-slate-500">Share the task and deadline with your students.</p><div className="mt-4 grid gap-3"><input value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Assignment title" className="h-10 rounded-lg border border-slate-200 bg-white px-3 text-sm outline-none focus:border-indigo-300" /><select value={course} onChange={(event) => setCourse(event.target.value)} aria-label="Select subject" className="h-10 rounded-lg border border-slate-200 bg-white px-3 text-sm outline-none focus:border-indigo-300"><option value="">Select subject</option><option value="FOP">FOP</option><option value="DLD">DLD</option><option value="BE">BE</option><option value="Probability and Stats">Probability and Stats</option><option value="IDT">IDT</option></select><label className="text-xs font-medium text-slate-600">Due date<input type="date" value={dueDate} onChange={(event) => setDueDate(event.target.value)} className="mt-1 h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm outline-none focus:border-indigo-300" /></label><label className="text-xs font-medium text-slate-600">Assignment document <span className="font-normal text-slate-400">(optional)</span><input type="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.zip" onChange={(event) => setDocumentName(event.target.files?.[0]?.name ?? '')} className="mt-1 block w-full rounded-lg border border-slate-200 bg-white p-2 text-sm font-normal text-slate-600 file:mr-3 file:rounded-md file:border-0 file:bg-indigo-50 file:px-3 file:py-1 file:text-xs file:font-semibold file:text-indigo-700" /></label><Button onClick={publishAssignment} disabled={!title.trim() || !course.trim() || !dueDate} className="bg-sky-500 text-white hover:bg-sky-600">Publish assignment</Button></div></div>
    <div className="rounded-xl border border-slate-200 p-4"><h3 className="font-semibold">Published this session</h3>{published.length === 0 ? <p className="mt-3 text-sm text-slate-500">No new assignments published yet.</p> : <div className="mt-3 flex flex-col gap-2">{published.map((item) => <div key={`${item.title}-${item.dueDate}`} className="rounded-lg bg-slate-50 p-3"><p className="text-sm font-semibold">{item.title}</p><p className="mt-1 text-xs text-slate-500">{item.course} · Due {item.dueDate}</p><div className="mt-3 flex items-center justify-between gap-3"><label className="cursor-pointer text-xs font-medium text-indigo-600 hover:text-indigo-700">{item.documentName ? item.documentName : 'Add document'}<input type="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.zip" className="sr-only" onChange={(event) => { const fileName = event.target.files?.[0]?.name; if (!fileName) return; setPublished((current) => current.map((publishedItem) => publishedItem.title === item.title ? { ...publishedItem, documentName: fileName } : publishedItem)); publishedAssignments = publishedAssignments.map((publishedItem) => publishedItem.title === item.title ? { ...publishedItem, documentName: fileName } : publishedItem) }} /></label><div className="flex flex-wrap items-center justify-end gap-2">{editingDueDate === item.title && <><input type="date" value={newDueDate} onChange={(event) => setNewDueDate(event.target.value)} className="h-9 rounded-lg border border-indigo-200 px-2 text-xs" /><Button size="sm" onClick={() => extendDueDate(item.title)} disabled={!newDueDate} className="bg-indigo-600 text-white hover:bg-indigo-700">Save date</Button></>}<Button variant="outline" onClick={() => { setEditingDueDate(item.title); setNewDueDate(item.dueDate) }} className="border-indigo-200 text-indigo-600 hover:bg-indigo-50">Extend due date</Button><Button variant="outline" onClick={() => { setPublished((current) => current.filter((publishedItem) => publishedItem.title !== item.title)); publishedAssignments = publishedAssignments.filter((publishedItem) => publishedItem.title !== item.title) }} className="border-rose-200 text-rose-600 hover:bg-rose-50">Remove assignment</Button></div></div><div className="mt-2 flex items-center justify-between gap-2"><label className="cursor-pointer text-xs font-medium text-indigo-600 hover:text-indigo-700">{item.documentName ? item.documentName : 'Add document'}<input type="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.zip" className="sr-only" onChange={(event) => { const fileName = event.target.files?.[0]?.name; if (!fileName) return; setPublished((current) => current.map((publishedItem) => publishedItem.title === item.title ? { ...publishedItem, documentName: fileName } : publishedItem)); publishedAssignments = publishedAssignments.map((publishedItem) => publishedItem.title === item.title ? { ...publishedItem, documentName: fileName } : publishedItem) }} /></label><Button variant="outline" className="border-rose-200 text-rose-600 hover:bg-rose-50" onClick={() => setPublished((current) => current.filter((publishedItem) => publishedItem.title !== item.title))}>Remove</Button></div></div>)}</div>}</div>
  </div>
}

function FacultyView() { const [respondingQuestion, setRespondingQuestion] = useState<string | null>(null); const [responseText, setResponseText] = useState(''); const [sentResponses, setSentResponses] = useState<string[]>([]); function sendResponse() { if (!respondingQuestion || !responseText.trim()) return; setSentResponses((current) => [...current, respondingQuestion]); setRespondingQuestion(null); setResponseText('') } return <><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><StatCard icon={Users} label="Active students" value="148" meta="+12 this semester" color="indigo" /><StatCard icon={FileText} label="Published assignments" value="18" meta="4 currently open" color="violet" /><StatCard icon={Clock3} label="To review" value="27" meta="8 due today" color="amber" /><StatCard icon={BarChart3} label="Class average" value="78%" meta="+2.8% this term" color="emerald" /></div><div className="mt-6 grid gap-6 xl:grid-cols-[1.4fr_0.6fr]"><section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="mb-5 flex items-center justify-between"><div><h2 className="font-bold">Recent submissions</h2><p className="mt-1 text-xs text-slate-500">Review and respond to student work.</p></div></div><div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="border-b border-slate-100 text-xs text-slate-400"><tr><th className="pb-3 font-medium">Student</th><th className="pb-3 font-medium">Assignment</th><th className="pb-3 font-medium">Submitted</th><th className="pb-3 font-medium">Status</th><th className="pb-3" /></tr></thead><tbody>{[['Aarav Sharma', 'FOP', '12 min ago', 'Needs review'], ['Ishaan Mehta', 'DLD', '34 min ago', 'Needs review'], ['Ananya Singh', 'Mathematics', 'Yesterday', 'Graded'], ['Kavya Patel', 'Statistics / IDT', 'Yesterday', 'Graded']].map(([name, assignment, submitted, status]) => <tr key={name + assignment} className="border-b border-slate-50"><td className="py-4 font-medium">{name}</td><td className="py-4 text-slate-500">{assignment}</td><td className="py-4 text-slate-500">{submitted}</td><td className="py-4"><Badge variant="outline" className={status === 'Graded' ? 'border-emerald-100 bg-emerald-50 text-emerald-700' : 'border-amber-100 bg-amber-50 text-amber-700'}>{status}</Badge></td><td className="py-4 text-right"><Button size="sm" variant="ghost">{status === 'Graded' ? 'View' : 'Review'}</Button></td></tr>)}</tbody></table></div></section></div><section className="mt-6 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="flex items-center justify-between"><div><h2 className="font-bold">Anonymous doubts</h2><p className="mt-1 text-xs text-slate-500">Questions waiting for a response.</p></div><Badge variant="secondary">9 unanswered</Badge></div><div className="mt-4 grid gap-3 md:grid-cols-2">{['FOP: Could you explain the difference between reliability and validity?', 'FOP: Which problem-solving method should we use for the next tutorial?', 'Mathematics: How do I approach the limits question in the worksheet?', 'Mathematics: Could you explain the difference between mean and median?', 'BE: Can you explain the diode circuit from today’s lab?', 'BE: Which components should we use for the practical assignment?', 'DLD: How does the flip-flop timing work?', 'DLD: Will the digital logic lab include Karnaugh maps?', 'What citation format should we use for the final report?'].map((question, index) => <div key={question} className="flex items-start gap-3 rounded-xl border border-slate-100 p-3"><div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-indigo-50 text-indigo-600"><CircleHelp className="size-4" /></div><div className="flex-1"><p className="text-sm leading-relaxed">{question}</p><p className="mt-1 text-xs text-slate-400">{index + 1} hour{index ? 's' : ''} ago</p></div>{sentResponses.includes(question) ? <span className="text-xs font-semibold text-emerald-600">Responded</span> : <Button size="sm" onClick={() => setRespondingQuestion(question)} className="bg-sky-500 text-white hover:bg-sky-600">Respond</Button>}</div>)}</div>{respondingQuestion && <div className="mt-4 rounded-xl border border-indigo-100 bg-indigo-50 p-4"><p className="text-sm font-semibold text-slate-900">Reply to: {respondingQuestion}</p><textarea value={responseText} onChange={(event) => setResponseText(event.target.value)} placeholder="Write a helpful response..." rows={3} className="mt-3 w-full rounded-lg border border-slate-200 bg-white p-3 text-sm outline-none focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100" /><div className="mt-3 flex justify-end gap-2"><Button variant="outline" onClick={() => { setRespondingQuestion(null); setResponseText('') }} className="border-sky-200 bg-sky-50 text-sky-700 hover:bg-sky-100">Cancel</Button><Button onClick={sendResponse} className="bg-indigo-600 text-white hover:bg-indigo-700">Send response</Button></div></div>}</section></> }

function StatCard({ icon: Icon, label, value, meta, color }: { icon: typeof FileText; label: string; value: string; meta: string; color: string }) { const iconStyles = { indigo: 'bg-indigo-50 text-indigo-600', amber: 'bg-amber-50 text-amber-600', emerald: 'bg-emerald-50 text-emerald-600', violet: 'bg-violet-50 text-violet-600' }[color] ?? 'bg-slate-50 text-slate-600'; return <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm"><div className="flex items-start justify-between"><div className={`flex size-9 items-center justify-center rounded-xl ${iconStyles}`}><Icon className="size-[18px]" /></div><MoreHorizontal className="size-4 text-slate-300" /></div><p className="mt-4 text-xs font-medium text-slate-500">{label}</p><p className="mt-1 text-2xl font-bold tracking-tight">{value}</p><p className="mt-1 text-xs text-slate-400">{meta}</p></div> }
