@echo off
setlocal
if not exist node_modules (
  echo Dependencies are not installed. Run setup.bat first.
  pause
  exit /b 1
)
where pnpm >nul 2>nul
if %errorlevel%==0 (
  start "CampusSubmit Server" cmd /k "pnpm dev"
) else (
  start "CampusSubmit Server" cmd /k "npm run dev"
)
echo Starting CampusSubmit...
timeout /t 6 /nobreak >nul
start "" "http://localhost:3000"
endlocal
