#!/usr/bin/env bash
set -euo pipefail

if [ ! -d node_modules ]; then
  echo "Dependencies are not installed. Run ./setup.sh first."
  exit 1
fi

if command -v pnpm >/dev/null 2>&1; then
  pnpm dev &
else
  npm run dev &
fi
SERVER_PID=$!
trap 'kill "$SERVER_PID" 2>/dev/null || true' EXIT

sleep 6
if command -v open >/dev/null 2>&1; then
  open "http://localhost:3000"
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "http://localhost:3000"
fi

wait "$SERVER_PID"
