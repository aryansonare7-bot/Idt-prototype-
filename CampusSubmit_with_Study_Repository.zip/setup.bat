@echo off
where pnpm >nul 2>nul
if %errorlevel%==0 (
  pnpm install
) else (
  npm install
)
echo CampusSubmit setup complete. Run start.bat to launch the app.
