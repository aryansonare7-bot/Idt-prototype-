import CampusSubmitDashboard from '@/components/campus-submit-dashboard'

export default function Page() {
  return <CampusSubmitDashboard />
}
